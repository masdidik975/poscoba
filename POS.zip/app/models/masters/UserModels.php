<?php

namespace App\models\masters;

use Illuminate\Database\Eloquent\Model;

class UserModels extends Model
{
    //
}
